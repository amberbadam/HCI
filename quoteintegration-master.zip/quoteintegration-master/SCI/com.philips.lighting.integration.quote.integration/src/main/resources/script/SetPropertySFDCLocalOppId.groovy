import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
       def xml = message.getBody(String.class)
       def completeXml= new XmlSlurper().parseText(xml)
       def SFDCOppId = completeXml.'**'.find{ node-> node.name() == 'Local_Opportunity_Id__c' }.text()
       message.setProperty("SFDCOppId", SFDCOppId)
	return message;
}

