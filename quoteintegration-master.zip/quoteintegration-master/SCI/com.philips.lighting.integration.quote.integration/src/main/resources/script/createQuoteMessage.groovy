import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

class Customer{ 
		def id
		def role
		def name
	}

class Properties{ 
	def name
	def value
}

def Message processData(Message message) {
	
	def customerId = message.getProperty("CustomerNumber");
	def salesOrg = message.getProperty("SalesOrganization"); 
	def disChannel = message.getProperty("DistributionChannel");
	def division = message.getProperty("Division");
	def languageValue = message.getProperty("Language");
	def loid = message.getProperty("SFDCOppId"); // "123456789";
	def salesAreaValue = salesOrg + "/" + disChannel + "/" + division;
		
	// Fill single customer	
	def customerList = [];
	
	customerId = customerId.replaceAll("^0+(?=\\d+\$)", ""); // Remove leading zeros
	customerList[0]= new Customer(id:customerId, role:"AG",name:"SoldTo");
	
	// Fill LOID property
	def propertyList = [];
	propertyList[0] = new Properties(name:"EditableCrmOpportunityId",value:loid);
	
	def addLineProperties = { inproduct ->
                                  def x = [];
                                  if(inproduct.type != null) x.add([ "name" : "LineItemText" , "value" : inproduct.type ] );
                                  if(inproduct.description != null) x.add([ "name" : "Description" , "value" : inproduct.description ]);
                                  return x;
                               };
                               	
	def body = message.getBody(String.class);
	
	def slurper = new groovy.json.JsonSlurper();
	def input = slurper.parseText(body);
	
	def builder = new groovy.json.JsonBuilder();
	
	def root = builder {
		"header" {
        	"language" languageValue
        	"title"	   input.projectName
        	"distributor" {
            	"salesArea"	salesAreaValue
            }
			"customers" customerList.collect{ customer -> 
				[
		       	"id": customer.id,
		       	"role": customer.role,
		       	"name": customer.name
		         
				]
			}
	         "properties" propertyList.collect{ property ->
	         	[
	            "name": property.name,
	            "value":property.value
	         	]
	         }
		}
         "lines" input.products.collect{  product -> 
         	[
         	"product":product.code,
         	"quantity":product.quantity,
         	"requestedPrice": product.requestedPrice.collect { price ->   
         		[
         			"stepId": "A",
         			"rate": price
         		]},
         	"properties": addLineProperties(product)
         	]
         	
         }
	}
	
	message.setBody(builder.toString());
	
	return message;
}

