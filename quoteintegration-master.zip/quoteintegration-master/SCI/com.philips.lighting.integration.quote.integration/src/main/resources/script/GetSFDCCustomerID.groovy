import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
       def xml = message.getBody(String.class)
       def completeXml= new XmlSlurper().parseText(xml)
 //    def SFDCCustomerID = completeXml.'**'.find{ node-> node.name() == 'Id' }.text()
 //      message.setProperty("SFDCId", SFDCCustomerID)
     
     def ids = completeXml.'**'.findAll{ node-> node.name() == 'Id' };
		 message.setProperty("SFDCCustomerId", ids.get(0).text());
         message.setProperty("SFDCRegionId", ids.get(1).text());
	return message;
}

