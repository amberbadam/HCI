import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def map = message.getProperties();
    def pload = map.get("payLoad");
    def ex    = map.get("CamelExceptionCaught");
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        messageLog.setStringProperty("Logging#1", "Printing Payload As Attachment");
        messageLog.addAttachmentAsString("RequestPayload:", pload, "text/plain");
     };
    if(ex!= null){
        messageLog.setStringProperty("Logging#2", "Printing Exception Message As Attachment")
        messageLog.addAttachmentAsString("Error:", ex.getResponseBody() , "text/plain");
        
        messageLog.setStringProperty("Logging#3", "Printing Exception Trace As Attachment")
        messageLog.addAttachmentAsString("Stacktrace:", ex.getStackTrace() as String, "text/plain");
    } 
     
    return message;
}