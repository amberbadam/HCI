import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	
	//Body 
	def body = message.getBody(String.class);
    def completeXml= new XmlSlurper().parseText(body);
    def CPQId = completeXml.'**'.find{ node-> node.name() == 'quoteId' }.text();
    message.setProperty("CPQId", quoteId);

	return message;
}

