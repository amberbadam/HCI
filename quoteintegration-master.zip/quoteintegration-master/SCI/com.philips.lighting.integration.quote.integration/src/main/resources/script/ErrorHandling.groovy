import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
 
   def map = message.getProperties();
   def ex = map.get("CamelExceptionCaught");
  
  
    if (ex!=null) {
		def body = message.getBody();
		message.setBody('test123535');
		
//		message.setBody(ex.getMessage());
		
	    // copy the value of http error code (i.e. 500) to a property
       //  message.setProperty("http.StatusCode",500);
      // copy the value of http error text (i.e. "Internal Server Error") to a property
     //message.setProperty("http.StatusText","bla");
		message.setHeader("STATUS_CODE", 500);
//		message.setHeader("STATUS_TEXT", "TEST TEST Validation failed");
        
	//	throw new org.apache.camel.CamelException("ValidationException",ex.getCause());

    }
   else{
		message.setBody('test123');
		
	message.setHeader("STATUS_CODE", 500);
//	message.setHeader("STATUS_TEXT", " ELSE Else Validation failed");

   }
      	
	return message;

}